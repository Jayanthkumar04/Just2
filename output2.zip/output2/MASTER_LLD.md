# LLD: Job-Board-Litee

> **8 Technical Use Cases** — generated from source code

---

## Table of Contents


### 🌐 HTTP Endpoints

- [UC-001 — Add Application](lld/UC-001_Add_Application.md)  
  `POST /application` · API Client · 1 steps · 0 rules
- [UC-002 — Get Application](lld/UC-002_Get_Application.md)  
  `GET /application` · API Client · 1 steps · 0 rules
- [UC-003 — Get Job](lld/UC-003_Get_Job.md)  
  `GET /job` · API Client · 1 steps · 0 rules
- [UC-004 — Get Job](lld/UC-004_Get_Job.md)  
  `GET /job/{id}` · API Client · 1 steps · 0 rules
- [UC-005 — Get Job](lld/UC-005_Get_Job.md)  
  `GET /job/search` · API Client · 1 steps · 0 rules
- [UC-006 — Get Job Location](lld/UC-006_Get_Job_Location.md)  
  `GET /job/location` · API Client · 1 steps · 0 rules
- [UC-007 — Add Job](lld/UC-007_Add_Job.md)  
  `POST /job` · API Client · 1 steps · 0 rules

### 🚀 Application Start

- [UC-008 — Start Job Board Litee](lld/UC-008_Start_Job_Board_Litee.md)  
  `main(String[] args) in JobBoardLiteeApplication` · JVM / OS Process · 1 steps · 0 rules

---

## Use Case Reference Cards

> Each card is a quick-reference summary.  Click the **📄 Full LLD** link to open the complete design document.

### UC-001 — Add Application  ·  POST /application

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `ApplicationController.addApplication()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-001_Add_Application.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🟢 POST `/application` |
| Call chain | `ApplicationController` → `ApplicationService` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **service**.addApplication() — Invoke service: create / persist — add Application

> 📄 [Open full LLD for UC-001](lld/UC-001_Add_Application.md)

---

### UC-002 — Get Application  ·  GET /application

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `ApplicationController.getAllApplications()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-002_Get_Application.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/application` |
| Call chain | `ApplicationController` → `ApplicationService` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **service**.getAllApplications() — Invoke service: retrieve — get All Applications

> 📄 [Open full LLD for UC-002](lld/UC-002_Get_Application.md)

---

### UC-003 — Get Job  ·  GET /job

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getAllJobs()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-003_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job` |
| Call chain | `JobController` → `JobService` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **service**.getAllJobs() — Invoke service: retrieve — get All Jobs

> 📄 [Open full LLD for UC-003](lld/UC-003_Get_Job.md)

---

### UC-004 — Get Job  ·  GET /job/{id}

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobById()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-004_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/{id}` |
| Call chain | `JobController` → `JobService` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **service**.getJobById() — Invoke service: retrieve — get Job By Id

> 📄 [Open full LLD for UC-004](lld/UC-004_Get_Job.md)

---

### UC-005 — Get Job  ·  GET /job/search

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobsBySearch()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-005_Get_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/search` |
| Call chain | `JobController` → `JobService` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **service**.getJobsBySearch() — Invoke service: retrieve — get Jobs By Search

> 📄 [Open full LLD for UC-005](lld/UC-005_Get_Job.md)

---

### UC-006 — Get Job Location  ·  GET /job/location

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.getJobsByLocation()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-006_Get_Job_Location.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/location` |
| Call chain | `JobController` → `JobService` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **service**.getJobsByLocation() — Invoke service: retrieve — get Jobs By Location

> 📄 [Open full LLD for UC-006](lld/UC-006_Get_Job_Location.md)

---

### UC-007 — Add Job  ·  POST /job

> 🌐 **HTTP Endpoints** &nbsp;|&nbsp; **Actor:** API Client &nbsp;|&nbsp; **Entry:** `JobController.addJob()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-007_Add_Job.md)

| Property | Value |
|---|---|
| Trigger | 🌐 **HTTP** — 🟢 POST `/job` |
| Call chain | `JobController` → `JobService` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **service**.addJob() — Invoke service: create / persist — add Job

> 📄 [Open full LLD for UC-007](lld/UC-007_Add_Job.md)

---

### UC-008 — Start Job Board Litee  ·  main(String[] args) in JobBoardLiteeApplication

> 🚀 **Application Start** &nbsp;|&nbsp; **Actor:** JVM / OS Process &nbsp;|&nbsp; **Entry:** `JobBoardLiteeApplication.main()` &nbsp;|&nbsp; [📄 Full LLD](lld/UC-008_Start_Job_Board_Litee.md)

| Property | Value |
|---|---|
| Trigger | 🚀 **Application Start** — `main(String[] args) in JobBoardLiteeApplication` |
| Call chain | `JobBoardLiteeApplication` |
| Steps | 1 |
| Rules | 0 |

**Implementation steps:**

1. `[service]` **SpringApplication**.run() — Call run on SpringApplication

> 📄 [Open full LLD for UC-008](lld/UC-008_Start_Job_Board_Litee.md)

---

